
const express = require('express');
const mongoose = require('mongoose');
const router = express.Router();

const User = require('../models/User');

// CREATE USER
router.post('/', async (req, res) => {
    try {
        const user = await User.create(req.body);

        res.status(201).json({
            message: 'User created successfully',
            user
        });

    } catch (error) {
        res.status(400).json({
            message: 'Error creating user',
            error: error.message
        });
    }
});


// READ ALL USERS
router.get('/', async (req, res) => {
    try {
        const users = await User.find();

        res.status(200).json(users);

    } catch (error) {
        res.status(500).json({
            message: error.message
        });
    }
});


// READ SINGLE USER
router.get('/:id', async (req, res) => {
    try {

        // Validate MongoDB ID
        if (!mongoose.isValidObjectId(req.params.id)) {
            return res.status(400).json({
                message: 'Invalid User ID'
            });
        }

        const user = await User.findById(req.params.id);

        if (!user) {
            return res.status(404).json({
                message: 'User not found'
            });
        }

        res.status(200).json(user);

    } catch (error) {
        res.status(500).json({
            message: error.message
        });
    }
});


// UPDATE USER
router.put('/:id', async (req, res) => {
    try {

        // Validate MongoDB ID
        if (!mongoose.isValidObjectId(req.params.id)) {
            return res.status(400).json({
                message: 'Invalid User ID'
            });
        }

        const user = await User.findByIdAndUpdate(
            req.params.id,
            req.body,
            {
                new: true,
                runValidators: true
            }
        );

        if (!user) {
            return res.status(404).json({
                message: 'User not found'
            });
        }

        res.status(200).json({
            message: 'User updated successfully',
            user
        });

    } catch (error) {
        res.status(400).json({
            message: error.message
        });
    }
});


// DELETE USER
router.delete('/:id', async (req, res) => {
    try {

        // Validate MongoDB ID
        if (!mongoose.isValidObjectId(req.params.id)) {
            return res.status(400).json({
                message: 'Invalid User ID'
            });
        }

        const user = await User.findByIdAndDelete(req.params.id);

        if (!user) {
            return res.status(404).json({
                message: 'User not found'
            });
        }

        res.status(200).json({
            message: 'User deleted successfully'
        });

    } catch (error) {
        res.status(500).json({
            message: error.message
        });
    }
});


// Export router
module.exports = router;
