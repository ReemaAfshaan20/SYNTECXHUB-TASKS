require('dotenv').config();

const express = require('express');
const mongoose = require('mongoose');

const app = express();

app.use(express.json());

app.use('/api/users', require('./src/routes/userRoutes'));


mongoose.connect(process.env.MONGODB_URI)
    .then(() => {
        console.log('MongoDB connected successfully');

        app.listen(process.env.PORT || 3000, () => {
            console.log('Server running on port 3000');
        });
    })
    .catch((error) => {
        console.log('MongoDB connection error:', error);
    });
